﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HugoLandEditeur
{
    public enum TypeTile
    {
        ObjetMonde,
        Monstre,
        Item,
        ClasseHero,
        Tile
    }

}
